Seeed Studio SenseCAP A1101 firmware
------------------------------------

For flashing instruction and details how to use this firmware, see the tutorial:
https://docs.edgeimpulse.com/docs/development-platforms/officially-supported-mcu-targets/seeed-sensecap-a1101

(c) Copyright 2023 Edge Impulse Inc., all rights reserved.
